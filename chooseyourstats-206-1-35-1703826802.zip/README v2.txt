Note: I test and install mdos using BG3 Mod Manager.
Installation
-------------
Move .pak into mods folder
Install mod with BG3 Mod Manager.
Enjoy!