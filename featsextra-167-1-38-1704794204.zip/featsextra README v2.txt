Installation
-------------
Download
Unzip
Please pak in mods folder
Install with BG3 Mod Manager
Enjoy!